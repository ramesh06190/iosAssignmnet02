//
//  ViewController.swift
//  Adapa_CalculatorApp
//
//  Created by Adapa,Pydi Venkata Satya Ramesh on 2/11/23.
//

import UIKit

class ViewController: UIViewController {
    var operand1:Double = -9.99
    var operand2:Double = -9.99
    var calcOperator: Character = " "
    
    @IBOutlet weak var resetOutlet: UILabel!
    
    @IBAction func ACbtn(_ sender: Any) {
        resetOutlet.text = ""
    }
    @IBAction func Cbtn(_ sender: Any) {
        resetOutlet.text = ""
    }
    @IBAction func PlusMinusbtn(_ sender: Any) {
        resetOutlet.text = "+"
        if calcOperator == " "{
            calcOperator = "+"
        }
    }
    @IBAction func Dividebtn(_ sender: Any) {
        resetOutlet.text = "÷"
    }
    @IBAction func Multiplybtn(_ sender: Any) {
        resetOutlet.text = "X"
    }
    @IBAction func Minusbtn(_ sender: Any) {
        resetOutlet.text = "-"
    }
    @IBAction func Plusbtn(_ sender: Any) {
        resetOutlet.text = "+"
    }
    @IBAction func Equalsbtn(_ sender: Any) {
        resetOutlet.text = "="
        if calcOperator == "+"{
            resetOutlet.text = "\(operand1+operand2)"
        }
        else if calcOperator == "-"{
            resetOutlet.text = "\(operand1-operand2)"
        }
        if calcOperator == "X"{
            resetOutlet.text = "\(operand1*operand2)"
        }
        if calcOperator == "÷"{
            resetOutlet.text = "\(operand1/operand2)"
        }
    }
    @IBAction func Percentagebtn(_ sender: Any) {
        resetOutlet.text = "%"
    }
    @IBAction func Sevenbtn(_ sender: Any) {
        resetOutlet.text = "7"
        if operand1 == -9.99{
            operand1 = 7
        }
        else {
            operand2 = 7
        }
    }
    @IBAction func Eightbtn(_ sender: Any) {
        resetOutlet.text = "8"
        if operand1 == -9.99{
            operand1 = 8
        }
        else {
            operand2 = 8
        }
    }
    @IBAction func Ninebtn(_ sender: Any) {
        resetOutlet.text = "9"
        if operand1 == -9.99{
            operand1 = 9
        }
        else {
            operand2 = 9
        }
    }
    @IBAction func Sixbtn(_ sender: Any) {
        resetOutlet.text = "6"
        if operand1 == -9.99{
            operand1 = 6
        }
        else {
            operand2 = 6
        }
    }
    @IBAction func Fivebtn(_ sender: Any) {
        resetOutlet.text = "5"
        if operand1 == -9.99{
            operand1 = 5
        }
        else {
            operand2 = 5
        }
    }
    @IBAction func Fourbtn(_ sender: Any) {
        resetOutlet.text = "4"
        if operand1 == -9.99{
            operand1 = 4
        }
        else {
            operand2 = 4
        }
    }
    @IBAction func Threebtn(_ sender: Any) {
        resetOutlet.text = "3"
        if operand1 == -9.99{
            operand1 = 3
        }
        else {
            operand2 = 3
        }
    }
    @IBAction func Twotn(_ sender: Any) {
        resetOutlet.text = "2"
        if operand1 == -9.99{
            operand1 = 2
        }
        else {
            operand2 = 2
        }
    }
    @IBAction func Onebtn(_ sender: Any) {
        resetOutlet.text = "1"
        if operand1 == -9.99{
            operand1 = 1
        }
        else {
            operand2 = 1
        }
    }
    @IBAction func Zerobtn(_ sender: Any) {
        resetOutlet.text = "0"
        if operand1 == -9.99{
            operand1 = 0
        }
        else {
            operand2 = 0
        }
    }
    @IBAction func Dotbtn(_ sender: Any) {
        resetOutlet.text = "."
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

